-- Tables for users, doctors, health profiles, records, alerts, appointments, analytics and audit logs, were created and added to the HealthTrack healthcare database. 
-- Create Database, Create Table, Insert Into, Create Index, and Select statements were used to add sample data, create relationships, create indexes, and view the information stored in the database.

-- Removing existing database
DROP DATABASE IF EXISTS HealthTrack;

-- Creating new database
CREATE DATABASE HealthTrack;

-- Selecting database
USE HealthTrack;


-- Creating users table
CREATE TABLE Users (

    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    phone_number VARCHAR(20),
    role ENUM(
        'PATIENT',
        'DOCTOR',
        'ADMIN'
    ) NOT NULL,
    account_status ENUM(
        'ACTIVE',
        'INACTIVE',
        'SUSPENDED'
    ) DEFAULT 'ACTIVE',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP

);


-- Creating health profiles table
CREATE TABLE HealthProfiles (

    profile_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE NOT NULL,
    date_of_birth DATE,
    gender VARCHAR(20),
    blood_type VARCHAR(5),
    height_cm DECIMAL(5,2),
    weight_kg DECIMAL(5,2),
    allergies TEXT,
    medical_conditions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_profile_user
    FOREIGN KEY(user_id)
    REFERENCES Users(user_id)
    ON DELETE CASCADE

);


-- Creating doctors table
CREATE TABLE Doctors (

    doctor_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE NOT NULL,
    specialization VARCHAR(100),
    license_number VARCHAR(100) UNIQUE NOT NULL,
    years_of_experience INT,

    CONSTRAINT fk_doctor_user
    FOREIGN KEY(user_id)
    REFERENCES Users(user_id)
    ON DELETE CASCADE

);


-- Creating health records table
CREATE TABLE HealthRecords (

    record_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    record_type VARCHAR(50) NOT NULL,
    value DECIMAL(10,2),
    unit VARCHAR(20),
    notes TEXT,
    recorded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_health_user
    FOREIGN KEY(user_id)
    REFERENCES Users(user_id)
    ON DELETE CASCADE

);


-- Creating alerts table
CREATE TABLE Alerts (

    alert_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    alert_type VARCHAR(50),
    severity ENUM(
        'LOW',
        'MEDIUM',
        'HIGH',
        'CRITICAL'
    ),
    message TEXT NOT NULL,
    alert_status ENUM(
        'UNREAD',
        'READ',
        'ACKNOWLEDGED',
        'RESOLVED'
    ) DEFAULT 'UNREAD',
    acknowledged_by INT,
    acknowledged_at DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_alert_user
    FOREIGN KEY(user_id)
    REFERENCES Users(user_id)
    ON DELETE CASCADE

);


-- Creating alert rules table
CREATE TABLE AlertRules (

    rule_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    vital_type VARCHAR(50),
    minimum_value DECIMAL(10,2),
    maximum_value DECIMAL(10,2),
    severity ENUM(
        'LOW',
        'MEDIUM',
        'HIGH',
        'CRITICAL'
    ),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY(user_id)
    REFERENCES Users(user_id)

);


-- Creating alert history table
CREATE TABLE AlertHistory (

    history_id INT AUTO_INCREMENT PRIMARY KEY,
    alert_id INT,
    action VARCHAR(100),
    performed_by INT,
    remarks TEXT,
    action_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY(alert_id)
    REFERENCES Alerts(alert_id)

);


-- Creating appointments table
CREATE TABLE Appointments (

    appointment_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_date DATETIME NOT NULL,
    reason TEXT,
    appointment_status ENUM(
        'SCHEDULED',
        'COMPLETED',
        'CANCELLED'
    ) DEFAULT 'SCHEDULED',

    FOREIGN KEY(patient_id)
    REFERENCES Users(user_id),

    FOREIGN KEY(doctor_id)
    REFERENCES Doctors(doctor_id)

);


-- Creating analytics history table
CREATE TABLE AnalyticsHistory (

    analytics_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    metric_name VARCHAR(100),
    metric_value DECIMAL(10,2),
    analysis_period_start DATE,
    analysis_period_end DATE,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY(user_id)
    REFERENCES Users(user_id)

);


-- Creating audit logs table
CREATE TABLE AuditLogs (

    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(255) NOT NULL,
    ip_address VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY(user_id)
    REFERENCES Users(user_id)

);


-- Creating index for health records
CREATE INDEX idx_health_user
ON HealthRecords(user_id);

-- Creating index for alerts
CREATE INDEX idx_alert_user
ON Alerts(user_id);

-- Creating index for alert status
CREATE INDEX idx_alert_status
ON Alerts(alert_status);

-- Creating index for record type
CREATE INDEX idx_record_type
ON HealthRecords(record_type);

-- Creating index for appointment date
CREATE INDEX idx_appointment_date
ON Appointments(appointment_date);


-- Adding sample users
INSERT INTO Users
(
full_name,
email,
password_hash,
phone_number,
role
)
VALUES
(
'John Tan',
'john@email.com',
'hash123',
'91234567',
'PATIENT'
),
(
'Dr Sarah Lee',
'sarah@clinic.com',
'hash456',
'92345678',
'DOCTOR'
),
(
'Admin User',
'admin@healthtrack.com',
'hash789',
'93456789',
'ADMIN'
);


-- Adding sample health profile
INSERT INTO HealthProfiles
(
user_id,
date_of_birth,
gender,
blood_type,
height_cm,
weight_kg
)
VALUES
(
1,
'1995-05-20',
'Male',
'O+',
175,
70
);


-- Adding sample doctor
INSERT INTO Doctors
(
user_id,
specialization,
license_number,
years_of_experience
)
VALUES
(
2,
'Cardiology',
'MED123456',
10
);


-- Adding sample health records
INSERT INTO HealthRecords
(
user_id,
record_type,
value,
unit,
notes
)
VALUES
(
1,
'Heart Rate',
78,
'bpm',
'Normal reading'
),
(
1,
'Oxygen Level',
98,
'%',
'Normal oxygen'
),
(
1,
'Temperature',
36.7,
'Celsius',
'Normal temperature'
);


-- Adding sample alert
INSERT INTO Alerts
(
user_id,
alert_type,
severity,
message
)
VALUES
(
1,
'Heart Rate Warning',
'HIGH',
'Heart rate exceeded normal limit'
);


-- Adding sample alert rules
INSERT INTO AlertRules
(
user_id,
vital_type,
minimum_value,
maximum_value,
severity
)
VALUES
(
1,
'Heart Rate',
50,
120,
'HIGH'
),
(
1,
'Oxygen Level',
88,
92,
'CRITICAL'
);


-- Adding sample appointment
INSERT INTO Appointments
(
patient_id,
doctor_id,
appointment_date,
reason
)
VALUES
(
1,
1,
'2026-07-15 10:30:00',
'Routine health check'
);


-- Adding sample analytics data
INSERT INTO AnalyticsHistory
(
user_id,
metric_name,
metric_value,
analysis_period_start,
analysis_period_end
)
VALUES
(
1,
'Average Heart Rate',
76,
'2026-07-01',
'2026-07-10'
);


-- Adding sample audit log
INSERT INTO AuditLogs
(
user_id,
action,
ip_address
)
VALUES
(
1,
'Viewed health records',
'192.168.1.10'
);


-- Displaying users
SELECT * FROM Users;

-- Displaying health profiles
SELECT * FROM HealthProfiles;

-- Displaying doctors
SELECT * FROM Doctors;

-- Displaying health records
SELECT * FROM HealthRecords;

-- Displaying alerts
SELECT * FROM Alerts;

-- Displaying alert rules
SELECT * FROM AlertRules;

-- Displaying appointments
SELECT * FROM Appointments;

-- Displaying analytics history
SELECT * FROM AnalyticsHistory;

-- Displaying audit logs
SELECT * FROM AuditLogs;