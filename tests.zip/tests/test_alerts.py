# Test cases were automated to validate for abnormal and normal patient vital signs alert generation. 
# The tests verified that the alert engine produced the correct types and level of alerts.

# Importing alert engine
from app.services.alert_engine import AlertEngine

# Creating alert engine instance
engine = AlertEngine()

# Testing critical heart rate detection
def test_high_heart_rate():

    # Checking patient vital signs
    alerts = engine.check_vitals(

        patient_id="123",

        heart_rate=170,

        oxygen=98,

        temperature=36

    )

    # Verifying alert generation
    assert len(alerts)==1

    # Verifying critical severity
    assert alerts[0]["severity"]=="CRITICAL"

# Testing low oxygen detection
def test_low_oxygen():

    # Checking patient vital signs
    alerts = engine.check_vitals(

        patient_id="123",

        heart_rate=70,

        oxygen=85,

        temperature=36

    )

    # Verifying oxygen alert
    assert alerts[0]["type"]=="OXYGEN"

# Testing normal patient values
def test_normal_values():

    # Checking patient vital signs
    alerts = engine.check_vitals(

        patient_id="123",

        heart_rate=75,

        oxygen=98,

        temperature=36

    )

    # Verifying absence of alerts
    assert len(alerts)==0