# Alert duration and severity were evaluated to determine whether an alert required escalation. 
# When critical alerts were not resolved within the specified time period, the alert status was changed.

# Importing date and time library
from datetime import datetime

# Creating alert escalation service
class EscalationService:

    # Checking alert status
    def check(self, alert):

        # Calculating alert duration
        age = (
            datetime.utcnow()
            -
            alert.created_at
        )

        # Checking escalation condition
        if (
            alert.severity=="CRITICAL"
            and age.seconds >300
        ):

            # Returning escalated status
            return "ESCALATED"

        # Returning current status
        return alert.status