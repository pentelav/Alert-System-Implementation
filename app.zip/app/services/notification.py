# Different notification methods were used to provide patient alerts in accordance with the severity level. 
# Multiple notifications were sent out via critical alert and a single notification via warning alert.

# Importing logging library
import logging

# Creating logger
logger=logging.getLogger()

# Creating notification service
class NotificationService:

    # Sending alert notifications
    def send(self, alert):

        # Reading alert severity
        severity=alert["severity"]

        # Sending critical notifications
        if severity=="CRITICAL":

            # Sending text notification
            self.sms(alert)

            # Sending application notification
            self.push(alert)

        # Sending warning notification
        elif severity=="WARNING":

            # Sending application notification
            self.push(alert)

    # Sending text notification
    def sms(self, alert):

        # Recording text notification
        logger.info(
            "SMS SENT %s",
            alert
        )

    # Sending application notification
    def push(self, alert):

        # Recording application notification
        logger.info(
            "PUSH SENT %s",
            alert
        )