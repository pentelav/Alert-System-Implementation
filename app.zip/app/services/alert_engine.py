# Patient vital signs were compared with the set health limits and abnormal conditions were detected. 
# Alerts and critical alerts were issued whenever values were measured outside of safe ranges.

# Importing alert rules
from app.config import RULES

# Creating alert evaluation class
class AlertEngine:

    # Checking patient vital signs
    def check_vitals(
        self,
        patient_id,
        heart_rate,
        oxygen,
        temperature
    ):

        # Creating alert list
        alerts=[]

        # Checking critical heart rate
        if (
            heart_rate < 40
            or heart_rate >150
        ):

            # Adding critical heart rate alert
            alerts.append({

                "type":
                "HEART_RATE",

                "severity":
                "CRITICAL",

                "message":
                "Critical heart rate"

            })

        # Checking abnormal heart rate
        elif (
            heart_rate <50
            or heart_rate >120
        ):

            # Adding warning heart rate alert
            alerts.append({

                "type":
                "HEART_RATE",

                "severity":
                "WARNING",

                "message":
                "Abnormal heart rate"

            })

        # Checking critical oxygen level
        if oxygen <88:

            # Adding critical oxygen alert
            alerts.append({

                "type":
                "OXYGEN",

                "severity":
                "CRITICAL",

                "message":
                "Low oxygen level"

            })

        # Checking low oxygen level
        elif oxygen <92:

            # Adding warning oxygen alert
            alerts.append({

                "type":
                "OXYGEN",

                "severity":
                "WARNING",

                "message":
                "Oxygen below normal"

            })

        # Checking critical temperature
        if temperature>40:

            # Adding critical temperature alert
            alerts.append({

                "type":
                "TEMPERATURE",

                "severity":
                "CRITICAL",

                "message":
                "High temperature"

            })

        # Returning alert list
        return alerts