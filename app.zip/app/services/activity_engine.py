# Patient activity duration was assessed to detect prolonged activity. 
# Warning message was issued for every period of inactivity that lasted beyond the specified time.

# Creating activity monitoring class
class ActivityEngine:

    # Checking patient activity
    def detect(
        self,
        inactive_minutes
    ):

        # Checking inactivity duration
        if inactive_minutes > 120:

            # Returning inactivity warning
            return {

              "type":
              "INACTIVITY",

              "severity":
              "WARNING",

              "message":
              "No movement detected"

            }

        # Returning no alert
        return None