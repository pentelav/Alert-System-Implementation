# Patient vital signs and acknowledgement information are checked and alerted to using input structures. 
# These definitions guaranteed that the data received was in the right format.

# Importing data validation library
from pydantic import BaseModel

# Creating patient vital input structure
class VitalInput(BaseModel):

    # Defining patient identifier
    patient_id: int

    # Defining heart rate value
    heart_rate: int

    # Defining oxygen level
    oxygen: float

    # Defining temperature value
    temperature: float

# Creating alert acknowledgement input structure
class AckInput(BaseModel):

    # Defining user identifier
    user_id: int

    # Defining acknowledgement comment
    comment: str