# Database models were developed to store Alert Rules, Alerts, User Information, and Health Records. 
# These formations of patient information and the real time monitoring of health.

# Importing database libraries
from sqlalchemy import Column, Integer, String, Text, DateTime, DECIMAL, Boolean
from sqlalchemy.sql import func

# Importing database connection
from .connection import Base

# Creating user table
class User(Base):

    __tablename__ = "Users"

    # Defining user identifier
    user_id = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    # Defining user name
    full_name = Column(
        String(100),
        nullable=False
    )

    # Defining email address
    email = Column(
        String(255),
        unique=True,
        nullable=False
    )

    # Defining password information
    password_hash = Column(
        String(255)
    )

    # Defining phone number
    phone_number = Column(
        String(20)
    )

    # Defining user role
    role = Column(
        String(20)
    )

    # Defining account status
    account_status = Column(
        String(20)
    )

    # Defining account creation time
    created_at = Column(
        DateTime,
        server_default=func.now()
    )

# Creating health record table
class HealthRecord(Base):

    __tablename__ = "HealthRecords"

    # Defining record identifier
    record_id = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    # Defining user identifier
    user_id = Column(
        Integer,
        nullable=False
    )

    # Defining health record type
    record_type = Column(
        String(50)
    )

    # Defining recorded value
    value = Column(
        DECIMAL(10,2)
    )

    # Defining measurement unit
    unit = Column(
        String(20)
    )

    # Defining additional notes
    notes = Column(
        Text
    )

    # Defining record time
    recorded_at = Column(
        DateTime,
        server_default=func.now()
    )

# Creating alert table
class Alert(Base):

    __tablename__ = "Alerts"

    # Defining alert identifier
    alert_id = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    # Defining user identifier
    user_id = Column(
        Integer,
        nullable=False
    )

    # Defining alert type
    alert_type = Column(
        String(50)
    )

    # Defining alert severity
    severity = Column(
        String(20)
    )

    # Defining alert message
    message = Column(
        Text,
        nullable=False
    )

    # Defining alert status
    alert_status = Column(
        String(20)
    )

    # Defining acknowledgement user
    acknowledged_by = Column(
        Integer
    )

    # Defining acknowledgement time
    acknowledged_at = Column(
        DateTime
    )

    # Defining alert creation time
    created_at = Column(
        DateTime,
        server_default=func.now()
    )

# Creating alert rule table
class AlertRule(Base):

    __tablename__ = "AlertRules"

    # Defining rule identifier
    rule_id = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    # Defining user identifier
    user_id = Column(
        Integer
    )

    # Defining vital type
    vital_type = Column(
        String(50)
    )

    # Defining minimum value
    minimum_value = Column(
        DECIMAL(10,2)
    )

    # Defining maximum value
    maximum_value = Column(
        DECIMAL(10,2)
    )

    # Defining severity level
    severity = Column(
        String(20)
    )

    # Defining active status
    is_active = Column(
        Boolean,
        default=True
    )