# A database connection was configured for the HealthTrack system using MySQL. 
# Database operations were accessed and closed safely by creating a database session and managing it.

# Importing database libraries
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# Defining database connection details
DATABASE_URL = (
    "mysql+pymysql://root:MySQL%4012%24@localhost:3306/HealthTrack"
)

# Creating database connection
engine = create_engine(
    DATABASE_URL,
    echo=True
)

# Creating database session
SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

# Creating base model
Base = declarative_base()

# Creating database session handler
def get_db():

    # Opening database session
    db = SessionLocal()

    try:
        yield db

    # Closing database session
    finally:
        db.close()