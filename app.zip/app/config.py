# Parameter setting for alert rules were loaded from a patient monitoring parameter file and ready for use during patient monitoring. 
# The configuration information was shared to assess health conditions.

# Importing configuration library
import yaml

# Loading alert rule settings
def load_rules():

    # Opening configuration file
    with open(
        "app/rules/alert_rules.yaml"
    ) as file:

        # Reading configuration data
        return yaml.safe_load(file)

# Storing alert rule settings
RULES = load_rules()