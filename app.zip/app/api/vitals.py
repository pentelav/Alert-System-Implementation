# Patient vital signs were recorded, assessed and monitored for abnormal values. 
# Abnormal values were detected and saved health records and alert information were generated.

# Importing required libraries
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

# Importing database connection
from app.database.connection import get_db

# Importing database models
from app.database.models import Alert, HealthRecord

# Importing input schema
from app.schemas.schemas import VitalInput

# Importing alert and notification services
from app.services.alert_engine import AlertEngine
from app.services.notification import NotificationService

# Creating router
router = APIRouter()

# Creating alert engine
alert_engine = AlertEngine()

# Creating notification service
notification = NotificationService()

# Receiving patient vital signs
@router.post("/vitals")
def receive_vitals(
    data: VitalInput,
    db: Session = Depends(get_db)
):

    # Creating health record entries
    records = [

        HealthRecord(
            user_id=data.patient_id,
            record_type="Heart Rate",
            value=data.heart_rate,
            unit="bpm",
            notes="Real-time monitoring"
        ),

        HealthRecord(
            user_id=data.patient_id,
            record_type="Oxygen Level",
            value=data.oxygen,
            unit="%",
            notes="Real-time monitoring"
        ),

        HealthRecord(
            user_id=data.patient_id,
            record_type="Temperature",
            value=data.temperature,
            unit="Celsius",
            notes="Real-time monitoring"
        )

    ]

    # Saving health records
    for record in records:
        db.add(record)

    # Checking patient vital signs
    detected_alerts = alert_engine.check_vitals(

        patient_id=data.patient_id,

        heart_rate=data.heart_rate,

        oxygen=data.oxygen,

        temperature=data.temperature

    )

    # Saving detected alerts
    for item in detected_alerts:

        # Creating alert record
        alert = Alert(

            user_id=data.patient_id,

            alert_type=item["type"],

            severity=item["severity"],

            message=item["message"],

            alert_status="UNREAD"

        )

        # Saving alert record
        db.add(alert)

        # Sending notification
        notification.send(item)

    # Saving all changes
    db.commit()

    # Returning processing result
    return {

        "patient_id": data.patient_id,

        "alerts_created": len(detected_alerts),

        "status": "processed"

    }