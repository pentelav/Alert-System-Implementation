# Records were pulled, acknowledged and resolved in an alerted manner using application endpoints. 
# The process updated alert information and returned the latest alert information after each operation.

# Importing required libraries
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime

# Importing database connection
from app.database.connection import get_db

# Importing database model
from app.database.models import Alert

# Importing input schema
from app.schemas.schemas import AckInput

# Creating router
router = APIRouter()

# Retrieving all alert records
@router.get("/alerts")
def get_alerts(
    db: Session = Depends(get_db)
):

    # Reading alert records
    alerts = db.query(Alert).all()

    # Returning alert records
    return alerts

# Acknowledging an alert
@router.put("/alerts/{id}/ack")
def acknowledge(
    id: int,
    data: AckInput,
    db: Session = Depends(get_db)
):

    # Searching for alert
    alert = (
        db.query(Alert)
        .filter(
            Alert.alert_id == id
        )
        .first()
    )

    # Checking alert availability
    if alert is None:

        raise HTTPException(
            status_code=404,
            detail="Alert not found"
        )

    # Updating alert status
    alert.alert_status = "ACKNOWLEDGED"

    # Recording user information
    alert.acknowledged_by = data.user_id

    # Recording acknowledgement time
    alert.acknowledged_at = datetime.now()

    # Saving updated information
    db.commit()

    # Refreshing alert record
    db.refresh(alert)

    # Returning updated alert details
    return {

        "message": "Alert acknowledged",

        "alert_id": alert.alert_id,

        "status": alert.alert_status,

        "acknowledged_by": alert.acknowledged_by,

        "acknowledged_at": alert.acknowledged_at

    }

# Resolving an alert
@router.put("/alerts/{id}/resolve")
def resolve_alert(
    id: int,
    db: Session = Depends(get_db)
):

    # Searching for alert
    alert = (
        db.query(Alert)
        .filter(
            Alert.alert_id == id
        )
        .first()
    )

    # Checking alert availability
    if alert is None:

        raise HTTPException(
            status_code=404,
            detail="Alert not found"
        )

    # Updating alert status
    alert.alert_status = "RESOLVED"

    # Saving updated information
    db.commit()

    # Refreshing alert record
    db.refresh(alert)

    # Returning updated alert details
    return {

        "message": "Alert resolved",

        "alert_id": alert.alert_id,

        "status": alert.alert_status

    }