# The application was started with endpoints for monitoring and alert management. 
# Status endpoints were also offered to check the availability of applications and system health.

# Importing FastAPI framework
from fastapi import FastAPI

# Importing API routes
from app.api import vitals
from app.api import alerts

# Creating FastAPI application
app = FastAPI(
    title="HealthTrack Healthcare Alert System",
    description="Real-time healthcare monitoring and alert management system",
    version="1.0.0"
)

# Registering vital monitoring routes
app.include_router(
    vitals.router,
    prefix="/api",
    tags=["Vital Monitoring"]
)

# Registering alert management routes
app.include_router(
    alerts.router,
    prefix="/api",
    tags=["Alert Management"]
)

# Creating home endpoint
@app.get("/")
def home():

    # Returning application information
    return {
        "application": "HealthTrack Alert System",
        "status": "running",
        "database": "MySQL",
        "version": "1.0.0"
    }

# Creating health check endpoint
@app.get("/health")
def health_check():

    # Returning service health status
    return {
        "service": "HealthTrack API",
        "status": "healthy"
    }